#' one real complex overlap
#'
#' @param x complex name
#' @return one real complex overlap against observed proteins
real_overlap <- function(x){   
  real_comp_prots <- complexes[[x]]
  overlap <- length(intersect(observed_prots,real_comp_prots))
  return(overlap)
}
#' one reference complex overlap
#'
#' @param x complex name
#' @return one reference overlap against observed proteins
ref_overlap <- function (x){         
  real_comp_size <- length(complexes[[x]])
  ref_comp <- sample(allprot,real_comp_size,replace=F)
  overlap <- length(intersect(observed_prots,ref_comp))
  return(overlap) 
}
#' empirical distribution
#'
#' @param x complex name
#' @return 1000 reference overlap against observed proteins
empirical_distribution <- function(x){          
  empirical_data <- replicate(1000, ref_overlap(x))
  return(empirical_data)
}
#' complex p_values
#'
#' @param complexes complex list
#' @param overlap_min overlap min between complexes and observed proteins
#' @return p values
pvals <- function(complexes,overlap_min){  
  pvals <- c()
  for (i in 1:length(complexes)){
    x <- names(complexes)[i]
    if (real_overlap(x) >= overlap_min){
      p <- length(empirical_distribution(x)[empirical_distribution(x)>=real_overlap(x)])/1000
    } else {
      p <- 1
    }
    pvals <- append(pvals,p)
  }
  names(pvals) <- names(complexes)
  return(pvals)
}
#' predicted protiens
#'
#' @param observed_prots observed proteins vector
#' @param complexes complex list
#' @param overlap_min overlap min between complexes and observed proteins
#' @return predicted protiens
predicted_proteins <- function(observed_prots,complexes,overlap_min,pval_threshold,bonferroni){
  # bonferroni defualt = FALSE
  #  if (missing(bonferroni)) bonferroni <- FALSE
  # pval_threshold defualt = 0.05
  #  if (missing(pval_threshold)) pval_threshold <- 0.05
  if (bonferroni == FALSE) {
    sig_complexes <- names(pvals(complexes,overlap_min)[pvals(complexes,overlap_min) < pval_threshold])
    sig_prots <- unique(unlist(complexes[sig_complexes]))
    predicted_prots <- setdiff(sig_prots,observed_prots)
  } else {
    # bonferroni correction
    ## real complex overlaps against observed proteins
    realoverlaps <- sapply(names(complexes),real_overlap)
    ## the number of t-test
    num_t_test <- length(realoverlaps[realoverlaps >= overlap_min])
    
    sig_complexes <- names(pvals(complexes,overlap_min)[pvals(complexes,overlap_min) < pval_threshold/num_t_test])
    sig_prots <- unique(unlist(complexes[sig_complexes]))
    predicted_prots <- setdiff(sig_prots,observed_prots)
  }
  return(predicted_prots)
}

